<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
   
<h1>insert</h1>
<form action="ins.php" method="post">
  <input type="text" name="id">
  
  <input type="text" name="name">
  
  <input type="text" name="lastname">
  
  <input type="submit" name="submit">
  
    </form>
</body>
</html>     
<?php 

$conn=new mysqli("localhost","root","","demo"); 

$id=$name=$lastname=" ";


if(isset($_POST['submit']))
{

$id= $_POST['id'];
$name= $_POST['name'];
$lastname= $_POST['lastname'];


$sql = "INSERT INTO emp(ids, names, lastnames)
VALUES ($id,'$name','$lastname')";


if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    // echo "Error: " . $sql . "<br>" . $conn->error;
}

}
$conn->close();

?>
